import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import adminRouter from "./admin";
import clientRouter from "./client";
import webhookRouter from "./webhook";
import widgetRouter from "./widget";
import telegramRouter from "./telegram";
import openaiRouter from "./openai";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(adminRouter);
router.use(clientRouter);
router.use(webhookRouter);
router.use(widgetRouter);
router.use(telegramRouter);
router.use(openaiRouter);

export default router;
