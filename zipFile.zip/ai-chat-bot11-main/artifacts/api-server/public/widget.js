(function () {
  "use strict";

  var currentScript = document.currentScript;
  var widgetKey = currentScript ? currentScript.getAttribute("data-key") : null;

  if (!widgetKey) {
    console.warn("[ChatWidget] No data-key attribute found on script tag.");
    return;
  }

  var scriptSrc = currentScript ? currentScript.src : "";
  var apiBase = scriptSrc.replace(/\/widget\.js.*$/, "");

  var SESSION_KEY = "chatwidget_session_" + widgetKey;
  var sessionId = localStorage.getItem(SESSION_KEY);
  if (!sessionId) {
    sessionId = "ws_" + Math.random().toString(36).slice(2) + Date.now().toString(36);
    localStorage.setItem(SESSION_KEY, sessionId);
  }

  var messages = [];
  var isOpen = false;
  var isLoading = false;
  var companyName = "Chat Support";

  function createStyles() {
    var style = document.createElement("style");
    style.textContent = [
      "#cw-container{position:fixed;bottom:24px;right:24px;z-index:2147483647;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif}",
      "#cw-btn{width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#3b82f6,#6366f1);border:none;cursor:pointer;box-shadow:0 4px 20px rgba(99,102,241,.4);display:flex;align-items:center;justify-content:center;transition:transform .2s,box-shadow .2s;outline:none}",
      "#cw-btn:hover{transform:scale(1.08);box-shadow:0 6px 24px rgba(99,102,241,.5)}",
      "#cw-btn svg{width:26px;height:26px;fill:white}",
      "#cw-badge{position:absolute;top:-2px;right:-2px;width:14px;height:14px;border-radius:50%;background:#22c55e;border:2px solid white;display:none}",
      "#cw-panel{position:absolute;bottom:68px;right:0;width:360px;max-height:520px;background:#fff;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.18);display:none;flex-direction:column;overflow:hidden;border:1px solid rgba(0,0,0,.08)}",
      "#cw-panel.open{display:flex}",
      "#cw-header{background:linear-gradient(135deg,#3b82f6,#6366f1);padding:16px 18px;color:white;display:flex;align-items:center;justify-content:space-between}",
      "#cw-header-info{display:flex;align-items:center;gap:10px}",
      "#cw-avatar{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:18px}",
      "#cw-title{font-weight:600;font-size:14px}",
      "#cw-subtitle{font-size:11px;opacity:.85;margin-top:1px}",
      "#cw-close{background:rgba(255,255,255,.15);border:none;cursor:pointer;color:white;border-radius:8px;width:28px;height:28px;display:flex;align-items:center;justify-content:center;font-size:18px;line-height:1;transition:background .15s}",
      "#cw-close:hover{background:rgba(255,255,255,.28)}",
      "#cw-messages{flex:1;overflow-y:auto;padding:16px;display:flex;flex-direction:column;gap:10px;background:#f8f9fb;min-height:200px}",
      "#cw-messages::-webkit-scrollbar{width:4px}#cw-messages::-webkit-scrollbar-thumb{background:#d1d5db;border-radius:2px}",
      ".cw-msg{max-width:80%;padding:10px 13px;border-radius:14px;font-size:13.5px;line-height:1.45;word-break:break-word;animation:cwfadein .2s ease}",
      ".cw-msg.bot{background:#fff;border:1px solid #e5e7eb;border-bottom-left-radius:4px;color:#1f2937;align-self:flex-start}",
      ".cw-msg.user{background:linear-gradient(135deg,#3b82f6,#6366f1);color:white;border-bottom-right-radius:4px;align-self:flex-end}",
      ".cw-typing{display:flex;align-items:center;gap:4px;padding:10px 14px}",
      ".cw-dot{width:7px;height:7px;border-radius:50%;background:#9ca3af;animation:cwbounce 1.2s infinite}",
      ".cw-dot:nth-child(2){animation-delay:.2s}.cw-dot:nth-child(3){animation-delay:.4s}",
      "#cw-footer{padding:10px 12px;background:#fff;border-top:1px solid #f0f0f0;display:flex;align-items:center;gap:8px}",
      "#cw-input{flex:1;border:1.5px solid #e5e7eb;border-radius:10px;padding:9px 12px;font-size:13.5px;outline:none;resize:none;font-family:inherit;line-height:1.4;max-height:80px;overflow-y:auto;transition:border-color .15s}",
      "#cw-input:focus{border-color:#6366f1}",
      "#cw-send{width:36px;height:36px;border-radius:9px;background:linear-gradient(135deg,#3b82f6,#6366f1);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:opacity .15s;flex-shrink:0}",
      "#cw-send:disabled{opacity:.4;cursor:not-allowed}",
      "#cw-send svg{width:17px;height:17px;fill:white}",
      "#cw-powered{text-align:center;padding:5px 0 8px;font-size:10px;color:#9ca3af}",
      "@keyframes cwfadein{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}",
      "@keyframes cwbounce{0%,60%,100%{transform:translateY(0)}30%{transform:translateY(-5px)}}",
      "@media(max-width:420px){#cw-panel{width:calc(100vw - 32px);right:-8px;bottom:72px}}",
    ].join("");
    document.head.appendChild(style);
  }

  function createHTML() {
    var container = document.createElement("div");
    container.id = "cw-container";
    container.innerHTML = [
      '<div id="cw-panel">',
        '<div id="cw-header">',
          '<div id="cw-header-info">',
            '<div id="cw-avatar">🤖</div>',
            '<div><div id="cw-title">' + escHtml(companyName) + '</div><div id="cw-subtitle">Online · Typically replies instantly</div></div>',
          '</div>',
          '<button id="cw-close" aria-label="Close chat">×</button>',
        '</div>',
        '<div id="cw-messages"></div>',
        '<div id="cw-footer">',
          '<textarea id="cw-input" rows="1" placeholder="Type a message..." aria-label="Chat message"></textarea>',
          '<button id="cw-send" aria-label="Send">',
            '<svg viewBox="0 0 24 24"><path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z"/></svg>',
          '</button>',
        '</div>',
        '<div id="cw-powered">Powered by ChatBot Platform</div>',
      '</div>',
      '<button id="cw-btn" aria-label="Open chat">',
        '<div id="cw-badge"></div>',
        '<svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg>',
      '</button>',
    ].join("");
    document.body.appendChild(container);
  }

  function escHtml(s) {
    return String(s).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
  }

  function scrollBottom() {
    var el = document.getElementById("cw-messages");
    if (el) el.scrollTop = el.scrollHeight;
  }

  function addMessage(role, text) {
    messages.push({ role: role, text: text });
    renderMessages();
  }

  function showTyping() {
    var el = document.getElementById("cw-messages");
    var existing = document.getElementById("cw-typing-indicator");
    if (existing || !el) return;
    var div = document.createElement("div");
    div.id = "cw-typing-indicator";
    div.className = "cw-msg bot cw-typing";
    div.innerHTML = '<span class="cw-dot"></span><span class="cw-dot"></span><span class="cw-dot"></span>';
    el.appendChild(div);
    scrollBottom();
  }

  function hideTyping() {
    var el = document.getElementById("cw-typing-indicator");
    if (el) el.remove();
  }

  function renderMessages() {
    var el = document.getElementById("cw-messages");
    if (!el) return;
    el.innerHTML = "";
    messages.forEach(function (m) {
      var div = document.createElement("div");
      div.className = "cw-msg " + m.role;
      div.textContent = m.text;
      el.appendChild(div);
    });
    scrollBottom();
  }

  function toggleOpen() {
    isOpen = !isOpen;
    var panel = document.getElementById("cw-panel");
    var badge = document.getElementById("cw-badge");
    if (!panel) return;
    if (isOpen) {
      panel.classList.add("open");
      badge.style.display = "none";
      if (messages.length === 0) {
        addMessage("bot", "👋 Hi! How can I help you today?");
      }
      setTimeout(function () {
        var inp = document.getElementById("cw-input");
        if (inp) inp.focus();
      }, 100);
    } else {
      panel.classList.remove("open");
    }
  }

  function sendMessage() {
    if (isLoading) return;
    var inp = document.getElementById("cw-input");
    if (!inp) return;
    var text = inp.value.trim();
    if (!text) return;
    inp.value = "";
    inp.style.height = "auto";
    addMessage("user", text);
    isLoading = true;
    var sendBtn = document.getElementById("cw-send");
    if (sendBtn) sendBtn.disabled = true;
    showTyping();

    fetch(apiBase + "/api/widget/" + encodeURIComponent(widgetKey) + "/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text, sessionId: sessionId }),
    })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        hideTyping();
        isLoading = false;
        if (sendBtn) sendBtn.disabled = false;
        if (data.response) {
          addMessage("bot", data.response);
        } else if (data.error) {
          addMessage("bot", "⚠️ " + data.error);
        }
      })
      .catch(function () {
        hideTyping();
        isLoading = false;
        if (sendBtn) sendBtn.disabled = false;
        addMessage("bot", "⚠️ Connection error. Please try again.");
      });
  }

  function bindEvents() {
    var btn = document.getElementById("cw-btn");
    var close = document.getElementById("cw-close");
    var send = document.getElementById("cw-send");
    var inp = document.getElementById("cw-input");

    if (btn) btn.addEventListener("click", toggleOpen);
    if (close) close.addEventListener("click", toggleOpen);
    if (send) send.addEventListener("click", sendMessage);
    if (inp) {
      inp.addEventListener("keydown", function (e) {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          sendMessage();
        }
      });
      inp.addEventListener("input", function () {
        this.style.height = "auto";
        this.style.height = Math.min(this.scrollHeight, 80) + "px";
      });
    }
  }

  function fetchConfig() {
    fetch(apiBase + "/api/widget/" + encodeURIComponent(widgetKey) + "/config")
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (data.name) {
          companyName = data.name;
          var titleEl = document.getElementById("cw-title");
          if (titleEl) titleEl.textContent = data.name;
        }
        var badge = document.getElementById("cw-badge");
        if (badge && data.isActive) badge.style.display = "block";
      })
      .catch(function () {});
  }

  function init() {
    createStyles();
    createHTML();
    bindEvents();
    fetchConfig();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
