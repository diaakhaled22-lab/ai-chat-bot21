import { useState } from "react";
import {
  useListCompanies,
  useToggleCompanyStatus,
  useDeleteCompany,
  useGetCompanyActivityLogs,
  getListCompaniesQueryKey,
  customFetch,
} from "@workspace/api-client-react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import {
  Search, MoreVertical, Trash2, Eye, Building2,
  CalendarClock, CheckCircle2, XCircle, Clock, Settings2,
  Gauge, AlertTriangle, Zap, FlaskConical, Loader2, CheckCircle, Bot,
} from "lucide-react";

import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

type Company = {
  id: number;
  name: string;
  clientName?: string | null;
  clientId: number;
  isActive: boolean;
  activationStart?: string | null;
  activationEnd?: string | null;
  generalInfo?: string | null;
  systemPrompt?: string | null;
  googleSheetsEnabled?: boolean;
  aiAgentApiKey?: string | null;
  telegramBotApiKey?: string | null;
  whatsappApiKey?: string | null;
  websiteChatbotKey?: string | null;
  monthlyTokenQuota?: number | null;
  createdAt: string;
};

function formatQuota(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
  return String(n);
}

const QUOTA_PRESETS = [
  { label: "100K",  value: 100_000 },
  { label: "500K",  value: 500_000 },
  { label: "1M",    value: 1_000_000 },
  { label: "5M",    value: 5_000_000 },
  { label: "10M",   value: 10_000_000 },
];

const ACTION_META: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  activated: {
    label: "Activated",
    icon: <CheckCircle2 className="w-3.5 h-3.5" />,
    color: "text-emerald-500",
  },
  deactivated: {
    label: "Deactivated",
    icon: <XCircle className="w-3.5 h-3.5" />,
    color: "text-amber-500",
  },
  expired: {
    label: "Auto-expired",
    icon: <Clock className="w-3.5 h-3.5" />,
    color: "text-red-500",
  },
  dates_set: {
    label: "Window updated",
    icon: <CalendarClock className="w-3.5 h-3.5" />,
    color: "text-blue-500",
  },
};

function ActivityLog({ companyId }: { companyId: number }) {
  const { data: logs, isLoading } = useGetCompanyActivityLogs(companyId);

  if (isLoading) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="flex gap-3 items-start">
            <Skeleton className="h-6 w-6 rounded-full shrink-0" />
            <div className="space-y-1 flex-1">
              <Skeleton className="h-3 w-32" />
              <Skeleton className="h-3 w-48" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (!logs || logs.length === 0) {
    return (
      <p className="text-sm text-muted-foreground text-center py-4">
        No activity recorded yet.
      </p>
    );
  }

  return (
    <ol className="relative border-l border-border ml-2 space-y-4">
      {logs.map((log) => {
        const meta = ACTION_META[log.action] ?? {
          label: log.action,
          icon: <Settings2 className="w-3.5 h-3.5" />,
          color: "text-muted-foreground",
        };
        return (
          <li key={log.id} className="ml-4">
            <div className={`absolute -left-[9px] w-[18px] h-[18px] rounded-full flex items-center justify-center bg-background border border-border ${meta.color}`}>
              {meta.icon}
            </div>
            <div className="flex flex-col gap-0.5">
              <div className="flex items-center gap-2">
                <span className={`text-sm font-medium ${meta.color}`}>{meta.label}</span>
                <span className="text-xs text-muted-foreground">by {log.performedBy}</span>
              </div>
              {log.note && (
                <p className="text-xs text-muted-foreground">{log.note}</p>
              )}
              <p className="text-xs text-muted-foreground/60">
                {new Date(log.createdAt).toLocaleString()}
              </p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}

function toDateInputValue(iso?: string | null) {
  if (!iso) return "";
  return iso.slice(0, 10);
}

function toIsoFromInput(dateStr: string) {
  if (!dateStr) return null;
  return new Date(dateStr + "T00:00:00").toISOString();
}

export default function AdminCompanies() {
  const { data: companies, isLoading } = useListCompanies();
  const [search, setSearch] = useState("");
  const [viewCompany, setViewCompany] = useState<Company | null>(null);
  const [activationTarget, setActivationTarget] = useState<Company | null>(null);
  const [activationForm, setActivationForm] = useState({ isActive: false, start: "", end: "" });
  const [quotaTarget, setQuotaTarget] = useState<Company | null>(null);
  const [quotaInput, setQuotaInput] = useState("");
  const [tgRegistering, setTgRegistering] = useState(false);
  const [tgStatus, setTgStatus] = useState<{ ok: boolean; message: string } | null>(null);
  const [tgWebhookTarget, setTgWebhookTarget] = useState<Company | null>(null);
  const [aiTestTarget, setAiTestTarget] = useState<Company | null>(null);
  const [aiTestLoading, setAiTestLoading] = useState(false);
  const [aiTestResult, setAiTestResult] = useState<{ status: string; provider?: string; model?: string; reply?: string; message?: string } | null>(null);

  const toggleStatus = useToggleCompanyStatus();
  const deleteCompany = useDeleteCompany();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const registerTelegramWebhook = async (company: Company) => {
    if (!company.telegramBotApiKey) return;
    setTgRegistering(true);
    setTgStatus(null);
    const webhookUrl = `${window.location.origin}/api/telegram/webhook/${company.telegramBotApiKey}`;
    try {
      const res = await fetch(`/api/telegram/register-webhook/${company.telegramBotApiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ webhookUrl }),
      });
      const data = await res.json();
      if (res.ok) {
        setTgStatus({ ok: true, message: "✅ Webhook registered! Telegram will now forward messages to this bot." });
      } else {
        setTgStatus({ ok: false, message: `❌ ${data.error}` });
      }
    } catch {
      setTgStatus({ ok: false, message: "❌ Connection error. Check the bot token and try again." });
    } finally {
      setTgRegistering(false);
    }
  };

  const handleRegisterWebhookFromDialog = () => {
    if (tgWebhookTarget) registerTelegramWebhook(tgWebhookTarget);
  };

  const runAiTest = async (company: Company) => {
    setAiTestLoading(true);
    setAiTestResult(null);
    try {
      const res = await fetch(`/api/admin/companies/${company.id}/test-ai`, { method: "POST" });
      const data = await res.json();
      setAiTestResult(data);
    } catch {
      setAiTestResult({ status: "error", message: "Connection error. Could not reach the server." });
    } finally {
      setAiTestLoading(false);
    }
  };

  const setQuotaMutation = useMutation({
    mutationFn: ({ id, quota }: { id: number; quota: number | null }) =>
      customFetch(`/api/admin/companies/${id}/quota`, {
        method: "PUT",
        body: JSON.stringify({ monthlyTokenQuota: quota }),
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: getListCompaniesQueryKey() });
      setQuotaTarget(null);
      toast({ title: "Token quota saved" });
    },
    onError: () => toast({ title: "Failed to save quota", variant: "destructive" }),
  });

  const openQuotaDialog = (company: Company) => {
    setQuotaTarget(company);
    setQuotaInput(company.monthlyTokenQuota ? String(company.monthlyTokenQuota) : "");
  };

  const handleSaveQuota = () => {
    if (!quotaTarget) return;
    const val = quotaInput.trim();
    const quota = val === "" ? null : parseInt(val.replace(/[^0-9]/g, ""), 10);
    if (val !== "" && (isNaN(quota!) || quota! <= 0)) {
      toast({ title: "Enter a valid number or leave blank to remove quota", variant: "destructive" });
      return;
    }
    setQuotaMutation.mutate({ id: quotaTarget.id, quota });
  };

  const openActivationDialog = (company: Company) => {
    setActivationTarget(company);
    setActivationForm({
      isActive: company.isActive,
      start: toDateInputValue(company.activationStart),
      end: toDateInputValue(company.activationEnd),
    });
  };

  const handleSaveActivation = () => {
    if (!activationTarget) return;
    if (activationForm.end && activationForm.start && activationForm.end < activationForm.start) {
      toast({ title: "End date must be after start date", variant: "destructive" });
      return;
    }
    toggleStatus.mutate(
      {
        id: activationTarget.id,
        data: {
          isActive: activationForm.isActive,
          activationStart: toIsoFromInput(activationForm.start),
          activationEnd: toIsoFromInput(activationForm.end),
        },
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCompaniesQueryKey() });
          setActivationTarget(null);
          toast({ title: "Activation settings saved" });
        },
        onError: () => {
          toast({ title: "Failed to save activation settings", variant: "destructive" });
        },
      }
    );
  };

  const handleDelete = (id: number) => {
    if (!confirm("Are you sure you want to delete this company? All associated data will be lost.")) return;
    deleteCompany.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListCompaniesQueryKey() });
        toast({ title: "Company deleted" });
      },
    });
  };

  const filteredCompanies = companies?.filter((c) =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.clientName || "").toLowerCase().includes(search.toLowerCase())
  ) as Company[] | undefined;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Companies</h1>
          <p className="text-muted-foreground mt-2">Monitor and manage all client companies.</p>
        </div>
      </div>

      <div className="flex items-center space-x-2 bg-card p-4 rounded-lg border border-border">
        <Search className="w-5 h-5 text-muted-foreground" />
        <Input
          placeholder="Search by company or client name..."
          className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 px-0"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="bg-card rounded-lg border border-border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Company</TableHead>
              <TableHead>Client</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Activation Window</TableHead>
              <TableHead>Token Quota</TableHead>
              <TableHead>Created</TableHead>
              <TableHead className="w-[80px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i}>
                  <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-6 w-20 rounded-full" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-36" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell></TableCell>
                </TableRow>
              ))
            ) : filteredCompanies?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  No companies found.
                </TableCell>
              </TableRow>
            ) : (
              filteredCompanies?.map((company) => {
                const endDate = company.activationEnd ? new Date(company.activationEnd) : null;
                const isExpired = !!endDate && endDate < new Date();
                return (
                  <TableRow key={company.id}>
                    <TableCell className="font-medium">
                      <div className="flex items-center">
                        <Building2 className="w-4 h-4 mr-2 text-muted-foreground" />
                        {company.name}
                      </div>
                    </TableCell>
                    <TableCell>{company.clientName ?? <span className="text-muted-foreground">—</span>}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        {company.isActive ? (
                          <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/20">Active</Badge>
                        ) : (
                          <Badge variant="outline" className="bg-muted text-muted-foreground">Inactive</Badge>
                        )}
                        {isExpired && (
                          <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/20 text-[10px]">Expired</Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      {company.activationStart || company.activationEnd ? (
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <CalendarClock className="w-3 h-3 shrink-0" />
                          <span>
                            {company.activationStart ? new Date(company.activationStart).toLocaleDateString() : "—"}
                            {" → "}
                            {company.activationEnd ? (
                              <span className={isExpired ? "text-red-500 font-medium" : ""}>
                                {new Date(company.activationEnd).toLocaleDateString()}
                              </span>
                            ) : "—"}
                          </span>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">No window set</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {company.monthlyTokenQuota ? (
                        <Badge variant="outline" className="text-xs text-blue-500 border-blue-500/30 bg-blue-500/10 gap-1">
                          <Gauge className="w-3 h-3" />
                          {formatQuota(company.monthlyTokenQuota)}/mo
                        </Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">Unlimited</span>
                      )}
                    </TableCell>
                    <TableCell>{new Date(company.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => setViewCompany(company)}>
                            <Eye className="w-4 h-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openActivationDialog(company)}>
                            <CalendarClock className="w-4 h-4 mr-2" />
                            Activation Settings
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => openQuotaDialog(company)}>
                            <Gauge className="w-4 h-4 mr-2" />
                            Set Token Quota
                          </DropdownMenuItem>
                          {company.aiAgentApiKey && (
                            <DropdownMenuItem onClick={() => { setAiTestTarget(company); setAiTestResult(null); runAiTest(company); }}>
                              <FlaskConical className="w-4 h-4 mr-2 text-violet-500" />
                              <span className="text-violet-500">Test AI Connection</span>
                            </DropdownMenuItem>
                          )}
                          {company.telegramBotApiKey && (
                            <DropdownMenuItem onClick={() => { setTgWebhookTarget(company); setTgStatus(null); }}>
                              <Zap className="w-4 h-4 mr-2 text-sky-500" />
                              <span className="text-sky-500">Register Telegram Webhook</span>
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleDelete(company.id)} className="text-destructive focus:text-destructive">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Activation settings dialog */}
      {/* Token Quota dialog */}
      <Dialog open={!!quotaTarget} onOpenChange={(open) => !open && setQuotaTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Gauge className="w-4 h-4 text-blue-500" />
              Set Monthly Token Quota
            </DialogTitle>
            <DialogDescription>
              Set the maximum tokens per calendar month for <strong>{quotaTarget?.name}</strong>. Leave blank for unlimited.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1">
              <Label htmlFor="quota-input">Monthly Token Limit</Label>
              <Input
                id="quota-input"
                placeholder="e.g. 1000000"
                value={quotaInput}
                onChange={(e) => setQuotaInput(e.target.value.replace(/[^0-9]/g, ""))}
                className="bg-background"
              />
              {quotaInput && !isNaN(parseInt(quotaInput)) && (
                <p className="text-xs text-muted-foreground">= {formatQuota(parseInt(quotaInput))} tokens / month</p>
              )}
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground">Quick Presets</Label>
              <div className="flex gap-2 flex-wrap">
                {QUOTA_PRESETS.map((p) => (
                  <Button key={p.label} type="button" size="sm" variant="outline" onClick={() => setQuotaInput(String(p.value))}>
                    {p.label}
                  </Button>
                ))}
                <Button type="button" size="sm" variant="ghost" className="text-muted-foreground" onClick={() => setQuotaInput("")}>
                  Clear (Unlimited)
                </Button>
              </div>
            </div>
            {quotaTarget?.monthlyTokenQuota && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground bg-muted px-3 py-2 rounded-md">
                <AlertTriangle className="w-3 h-3 shrink-0" />
                Current quota: {formatQuota(quotaTarget.monthlyTokenQuota)} tokens/month
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setQuotaTarget(null)}>Cancel</Button>
            <Button onClick={handleSaveQuota} disabled={setQuotaMutation.isPending}>
              {setQuotaMutation.isPending ? "Saving…" : "Save Quota"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!activationTarget} onOpenChange={(open) => !open && setActivationTarget(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Activation Settings</DialogTitle>
            <DialogDescription>
              Set the active state and optional date window for <strong>{activationTarget?.name}</strong>.
              The company will automatically become inactive when the end date is reached.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-5 py-2">
            <div className="flex items-center justify-between rounded-lg border border-border p-4">
              <div>
                <p className="text-sm font-medium">Active</p>
                <p className="text-xs text-muted-foreground mt-0.5">Allow this company's chatbot to operate</p>
              </div>
              <Switch
                checked={activationForm.isActive}
                onCheckedChange={(v) => setActivationForm((f) => ({ ...f, isActive: v }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="act-start">Start Date</Label>
                <Input
                  id="act-start"
                  type="date"
                  value={activationForm.start}
                  onChange={(e) => setActivationForm((f) => ({ ...f, start: e.target.value }))}
                />
                <p className="text-xs text-muted-foreground">Optional — when activation begins</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="act-end">End Date</Label>
                <Input
                  id="act-end"
                  type="date"
                  value={activationForm.end}
                  onChange={(e) => setActivationForm((f) => ({ ...f, end: e.target.value }))}
                />
                <p className="text-xs text-muted-foreground">Auto-deactivates on this date</p>
              </div>
            </div>
            {activationForm.end && (
              <p className="text-xs text-amber-500 bg-amber-500/10 border border-amber-500/20 rounded-md px-3 py-2">
                The system checks every minute and will automatically set this company to Inactive once the end date passes.
              </p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setActivationTarget(null)}>Cancel</Button>
            <Button onClick={handleSaveActivation} disabled={toggleStatus.isPending}>
              {toggleStatus.isPending ? "Saving..." : "Save Settings"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View details dialog */}
      <Dialog open={!!viewCompany} onOpenChange={(open) => !open && setViewCompany(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Company Details</DialogTitle>
            <DialogDescription>Overview of company configuration and activity history</DialogDescription>
          </DialogHeader>
          {viewCompany && (
            <div className="space-y-6 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Company Name</h4>
                  <p className="text-foreground font-medium">{viewCompany.name}</p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Client Name</h4>
                  <p className="text-foreground">{viewCompany.clientName ?? "—"}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">Start Date</h4>
                  <p className="text-foreground text-sm">
                    {viewCompany.activationStart ? new Date(viewCompany.activationStart).toLocaleDateString() : "Not set"}
                  </p>
                </div>
                <div>
                  <h4 className="text-sm font-medium text-muted-foreground mb-1">End Date</h4>
                  <p className="text-foreground text-sm">
                    {viewCompany.activationEnd ? new Date(viewCompany.activationEnd).toLocaleDateString() : "Not set"}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">General Info</h4>
                <div className="bg-muted p-3 rounded-md text-sm whitespace-pre-wrap">
                  {viewCompany.generalInfo || "Not provided"}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-1">System Prompt</h4>
                <div className="bg-muted p-3 rounded-md text-sm font-mono whitespace-pre-wrap max-h-40 overflow-y-auto">
                  {viewCompany.systemPrompt || "Not provided"}
                </div>
              </div>

              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-3">Integrations</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${viewCompany.googleSheetsEnabled ? "bg-emerald-500" : "bg-muted"}`} />
                    <span className="text-sm">Google Sheets</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${viewCompany.aiAgentApiKey ? "bg-emerald-500" : "bg-muted"}`} />
                    <span className="text-sm">AI Agent</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${viewCompany.telegramBotApiKey ? "bg-emerald-500" : "bg-muted"}`} />
                    <span className="text-sm">Telegram Bot</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${viewCompany.whatsappApiKey ? "bg-emerald-500" : "bg-muted"}`} />
                    <span className="text-sm">WhatsApp</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${viewCompany.websiteChatbotKey ? "bg-emerald-500" : "bg-muted"}`} />
                    <span className="text-sm">Website Widget</span>
                  </div>
                </div>
              </div>

              {viewCompany.telegramBotApiKey && (
                <div className="rounded-lg border border-sky-500/30 bg-sky-500/5 p-4 space-y-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">✈️</span>
                    <h4 className="text-sm font-semibold">Telegram Webhook</h4>
                  </div>
                  <div className="space-y-1">
                    <p className="text-xs text-muted-foreground">Webhook URL</p>
                    <pre className="bg-muted/40 border border-border rounded px-3 py-2 font-mono text-xs overflow-x-auto">
                      {`${window.location.origin}/api/telegram/webhook/${viewCompany.telegramBotApiKey}`}
                    </pre>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      type="button"
                      size="sm"
                      onClick={() => registerTelegramWebhook(viewCompany)}
                      disabled={tgRegistering}
                      className="bg-sky-500 hover:bg-sky-600 text-white gap-1.5"
                    >
                      {tgRegistering ? (
                        <><span className="animate-spin inline-block w-3 h-3 border-2 border-white/30 border-t-white rounded-full" /> Registering…</>
                      ) : (
                        <><Zap className="w-3.5 h-3.5" /> Register Webhook</>
                      )}
                    </Button>
                    <p className="text-xs text-muted-foreground">Re-register if the bot stops responding</p>
                  </div>
                  {tgStatus && (
                    <div className={`rounded px-3 py-2 text-xs ${tgStatus.ok ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400" : "bg-red-500/10 border border-red-500/30 text-red-600 dark:text-red-400"}`}>
                      {tgStatus.message}
                    </div>
                  )}
                </div>
              )}

              <div>
                <h4 className="text-sm font-medium text-muted-foreground mb-3">Activity Log</h4>
                <ActivityLog companyId={viewCompany.id} />
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Test AI Dialog */}
      <Dialog open={!!aiTestTarget} onOpenChange={(open) => { if (!open) { setAiTestTarget(null); setAiTestResult(null); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-violet-500" />
              Test AI Connection
            </DialogTitle>
            <DialogDescription>
              Sending a test message to <strong>{aiTestTarget?.name}</strong>'s AI agent.
            </DialogDescription>
          </DialogHeader>
          <div className="py-2 space-y-4">
            {aiTestLoading && (
              <div className="flex items-center gap-3 rounded-xl border border-border bg-muted/30 px-4 py-4 text-sm text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin shrink-0 text-violet-500" />
                <span>Connecting to AI provider and sending test message…</span>
              </div>
            )}
            {!aiTestLoading && aiTestResult && (
              <>
                {/* Status row */}
                <div className={`flex items-start gap-3 rounded-xl border px-4 py-3 text-sm ${
                  aiTestResult.status === "ok"
                    ? "border-emerald-500/30 bg-emerald-500/10"
                    : aiTestResult.status === "no_key"
                    ? "border-amber-500/30 bg-amber-500/10"
                    : "border-red-500/30 bg-red-500/10"
                }`}>
                  {aiTestResult.status === "ok" ? (
                    <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  ) : aiTestResult.status === "no_key" ? (
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                  )}
                  <div className="space-y-0.5">
                    <p className={`font-medium ${
                      aiTestResult.status === "ok" ? "text-emerald-700 dark:text-emerald-400" :
                      aiTestResult.status === "no_key" ? "text-amber-700 dark:text-amber-400" :
                      "text-red-700 dark:text-red-400"
                    }`}>
                      {aiTestResult.status === "ok" ? "AI is working correctly" :
                       aiTestResult.status === "no_key" ? "No API key configured" :
                       aiTestResult.status === "quota_exceeded" ? "Quota / rate limit exceeded" :
                       aiTestResult.status === "invalid_key" ? "Invalid API key" :
                       "Connection failed"}
                    </p>
                    {aiTestResult.provider && (
                      <p className="text-xs text-muted-foreground font-mono">
                        {aiTestResult.provider} / {aiTestResult.model}
                      </p>
                    )}
                  </div>
                </div>

                {/* AI Reply */}
                {aiTestResult.status === "ok" && aiTestResult.reply && (
                  <div className="space-y-1.5">
                    <p className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                      <Bot className="w-3.5 h-3.5" /> AI Response
                    </p>
                    <div className="rounded-xl border border-border bg-muted/20 px-4 py-3 text-sm italic text-foreground">
                      "{aiTestResult.reply}"
                    </div>
                  </div>
                )}

                {/* Error detail */}
                {aiTestResult.status !== "ok" && aiTestResult.status !== "no_key" && aiTestResult.message && (
                  <div className="space-y-1.5">
                    <p className="text-xs font-medium text-muted-foreground">Error detail</p>
                    <pre className="text-xs text-red-600 dark:text-red-400 bg-red-500/5 border border-red-500/20 rounded-lg px-3 py-2.5 overflow-x-auto whitespace-pre-wrap break-all">
                      {aiTestResult.message}
                    </pre>
                  </div>
                )}

                {/* No key guidance */}
                {aiTestResult.status === "no_key" && (
                  <p className="text-xs text-muted-foreground">
                    Ask the client to add an AI API key in their Configuration page, or set it via the admin panel.
                  </p>
                )}
              </>
            )}
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => { setAiTestTarget(null); setAiTestResult(null); }}>Close</Button>
            {aiTestTarget && !aiTestLoading && (
              <Button
                onClick={() => runAiTest(aiTestTarget)}
                className="bg-violet-500 hover:bg-violet-600 text-white gap-2"
              >
                <FlaskConical className="w-3.5 h-3.5" />
                Run Again
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Telegram Webhook Dialog */}
      <Dialog open={!!tgWebhookTarget} onOpenChange={(open) => { if (!open) { setTgWebhookTarget(null); setTgStatus(null); setTgRegistering(false); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-sky-500" />
              Register Telegram Webhook
            </DialogTitle>
            <DialogDescription>
              Tell Telegram to send all messages from <strong>{tgWebhookTarget?.name}</strong>'s bot to this server.
            </DialogDescription>
          </DialogHeader>
          {tgWebhookTarget && (
            <div className="space-y-4 py-2">
              <div className="space-y-1.5">
                <p className="text-xs font-medium text-muted-foreground">Webhook URL that will be registered:</p>
                <pre className="bg-muted/40 border border-border rounded-lg px-3 py-2.5 font-mono text-xs overflow-x-auto whitespace-pre-wrap break-all">
                  {`${window.location.origin}/api/telegram/webhook/${tgWebhookTarget.telegramBotApiKey}`}
                </pre>
              </div>
              {!tgWebhookTarget.isActive && (
                <div className="flex items-start gap-2 rounded-lg bg-amber-500/10 border border-amber-500/30 px-3 py-2.5 text-xs text-amber-600 dark:text-amber-400">
                  <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  This company is inactive. The webhook will be registered but the bot will not reply until activated.
                </div>
              )}
              {tgStatus && (
                <div className={`rounded-lg border px-3 py-2.5 text-sm ${tgStatus.ok ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "border-red-500/30 bg-red-500/10 text-red-600 dark:text-red-400"}`}>
                  {tgStatus.message}
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => { setTgWebhookTarget(null); setTgStatus(null); }}>Cancel</Button>
            <Button
              onClick={handleRegisterWebhookFromDialog}
              disabled={tgRegistering}
              className="bg-sky-500 hover:bg-sky-600 text-white gap-2"
            >
              {tgRegistering ? (
                <><span className="animate-spin inline-block w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full" /> Registering…</>
              ) : (
                <><Zap className="w-3.5 h-3.5" /> Register Webhook</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
