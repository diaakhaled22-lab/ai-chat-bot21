import { useState, useRef, useCallback, useEffect } from "react";
import { Bot, Send, RotateCcw, User, Loader2, FlaskConical, Sparkles, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useGetClientCompany } from "@workspace/api-client-react";
import { cn } from "@/lib/utils";

type Message = { role: "user" | "assistant"; content: string };

function MessageBubble({ role, content }: { role: "user" | "assistant"; content: string }) {
  const isUser = role === "user";
  return (
    <div className={cn("flex gap-3 max-w-full", isUser ? "flex-row-reverse" : "flex-row")}>
      <div className={cn(
        "w-8 h-8 rounded-full flex items-center justify-center shrink-0 mt-0.5",
        isUser ? "bg-primary text-primary-foreground" : "bg-muted border border-border"
      )}>
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-primary" />}
      </div>
      <div className={cn(
        "max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap break-words",
        isUser
          ? "bg-primary text-primary-foreground rounded-tr-sm"
          : "bg-muted border border-border rounded-tl-sm"
      )}>
        {content}
      </div>
    </div>
  );
}

function TypingIndicator({ botName }: { botName: string }) {
  return (
    <div className="flex gap-3">
      <div className="w-8 h-8 rounded-full flex items-center justify-center shrink-0 bg-muted border border-border">
        <Bot className="w-4 h-4 text-primary" />
      </div>
      <div className="bg-muted border border-border rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1.5">
        <span className="text-xs text-muted-foreground mr-1">{botName} is typing</span>
        <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/60 animate-bounce [animation-delay:0ms]" />
        <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/60 animate-bounce [animation-delay:150ms]" />
        <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/60 animate-bounce [animation-delay:300ms]" />
      </div>
    </div>
  );
}

export default function ClientChatbotTrial() {
  const { data: company, isLoading: companyLoading } = useGetClientCompany();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [streamContent, setStreamContent] = useState("");
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const scrollToBottom = useCallback(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => { scrollToBottom(); }, [messages, streamContent, scrollToBottom]);

  const botName = company?.name ?? "Your Chatbot";
  const hasSystemPrompt = !!(company?.systemPrompt?.trim() || company?.generalInfo?.trim());

  const sendMessage = async () => {
    if (!input.trim() || streaming) return;
    const userText = input.trim();
    setInput("");
    setError(null);

    const updatedMessages: Message[] = [...messages, { role: "user", content: userText }];
    setMessages(updatedMessages);
    setStreaming(true);
    setStreamContent("");

    const abort = new AbortController();
    abortRef.current = abort;

    try {
      const res = await fetch("/api/client/chatbot-trial", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: updatedMessages }),
        signal: abort.signal,
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error ?? "Request failed");
      }

      if (!res.body) throw new Error("No response body");

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let accumulated = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const text = decoder.decode(value);
        for (const line of text.split("\n")) {
          if (!line.startsWith("data: ")) continue;
          try {
            const json = JSON.parse(line.slice(6));
            if (json.content) {
              accumulated += json.content;
              setStreamContent(accumulated);
            }
            if (json.done) {
              setMessages((prev) => [...prev, { role: "assistant", content: accumulated }]);
              setStreamContent("");
            }
            if (json.error) {
              setError(json.error);
            }
          } catch { /* partial chunk */ }
        }
      }
    } catch (err: any) {
      if (err?.name !== "AbortError") {
        setError(err?.message ?? "Failed to connect. Please try again.");
        setMessages((prev) => prev.slice(0, -1));
      }
    } finally {
      setStreaming(false);
      setStreamContent("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const clearChat = () => {
    if (streaming) abortRef.current?.abort();
    setMessages([]);
    setStreamContent("");
    setError(null);
    setTimeout(() => textareaRef.current?.focus(), 50);
  };

  if (companyLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[calc(100vh-4rem)] -mt-6 -mx-6 overflow-hidden">
      {/* Header */}
      <div className="px-6 py-3 border-b border-border bg-background/80 backdrop-blur-sm shrink-0 flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-primary/15 flex items-center justify-center">
          <FlaskConical className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="font-semibold text-sm truncate">Try: {botName}</p>
            <Badge variant="outline" className="text-[10px] shrink-0 border-primary/30 text-primary bg-primary/5">
              <Sparkles className="w-2.5 h-2.5 mr-1" /> Free Trial
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground">
            {hasSystemPrompt
              ? "Running with your system prompt & company info"
              : "No system prompt configured yet — add one in Company Settings"}
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={clearChat} disabled={messages.length === 0 && !streaming}>
          <RotateCcw className="w-3.5 h-3.5 mr-1.5" /> Reset
        </Button>
      </div>

      {/* No system prompt warning */}
      {!hasSystemPrompt && (
        <div className="mx-6 mt-3 shrink-0 flex items-start gap-2.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm">
          <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
          <p className="text-amber-700 dark:text-amber-400">
            Your chatbot doesn't have a system prompt yet. Go to <strong>Company Settings</strong> to add one, then come back here to test it.
          </p>
        </div>
      )}

      {/* Messages */}
      <ScrollArea className="flex-1 px-6 py-4">
        {messages.length === 0 && !streaming && (
          <div className="flex flex-col items-center justify-center gap-4 py-16 text-center">
            <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Bot className="w-7 h-7 text-primary" />
            </div>
            <div>
              <p className="font-semibold text-base">{botName}</p>
              <p className="text-sm text-muted-foreground mt-1 max-w-xs">
                Type a message below to preview how your chatbot responds to customers.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 mt-1 justify-center max-w-sm">
              {["Hello! What can you help me with?", "What are your working hours?", "How do I get started?"].map((s) => (
                <button
                  key={s}
                  onClick={() => { setInput(s); textareaRef.current?.focus(); }}
                  className="text-xs border border-border rounded-full px-3 py-1.5 hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <div className="space-y-4 max-w-3xl mx-auto">
          {messages.map((m, i) => (
            <MessageBubble key={i} role={m.role} content={m.content} />
          ))}
          {streaming && streamContent && (
            <MessageBubble role="assistant" content={streamContent} />
          )}
          {streaming && !streamContent && (
            <TypingIndicator botName={botName} />
          )}
          {error && (
            <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 border border-destructive/20 rounded-xl px-4 py-2.5">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              {error}
            </div>
          )}
          <div ref={bottomRef} />
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="px-6 py-3 border-t border-border bg-background/80 backdrop-blur-sm shrink-0">
        <div className="max-w-3xl mx-auto flex gap-2 items-end">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={`Message ${botName}… (Enter to send)`}
            rows={1}
            disabled={streaming}
            className="resize-none min-h-[44px] max-h-[180px] bg-muted/50 border-border focus-visible:ring-primary/30"
            style={{ fieldSizing: "content" } as React.CSSProperties}
          />
          {streaming ? (
            <Button variant="outline" size="icon" className="h-[44px] w-[44px] shrink-0"
              onClick={() => { abortRef.current?.abort(); setStreaming(false); setStreamContent(""); }}>
              <RotateCcw className="w-4 h-4" />
            </Button>
          ) : (
            <Button onClick={sendMessage} disabled={!input.trim()} size="icon" className="h-[44px] w-[44px] shrink-0">
              <Send className="w-4 h-4" />
            </Button>
          )}
        </div>
        <p className="text-center text-[10px] text-muted-foreground/50 mt-1.5">
          This preview uses the platform's AI. Your live chatbot uses your own API key.
        </p>
      </div>
    </div>
  );
}
