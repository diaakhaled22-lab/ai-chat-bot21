import { useEffect, useRef, useState, useCallback } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Copy, Check, Info, Bot, MessageCircle, Zap, Database, FileSpreadsheet, KeyRound, Lock, Eye, EyeOff, UserRound, ChevronDown, AlertTriangle, Gauge, Send, RotateCcw } from "lucide-react";
import { useGetClientCompany, useCreateClientCompany, useUpdateClientCompany, useTestClientGoogleSheetConnection, getGetClientCompanyQueryKey, customFetch } from "@workspace/api-client-react";
import { useQueryClient, useQuery } from "@tanstack/react-query";

import { Input } from "@/components/ui/input";
import { PasswordInput } from "@/components/ui/password-input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";

const AI_PROVIDERS = {
  openai: {
    label: "OpenAI",
    icon: "🟢",
    keyLabel: "OPENAI_API_KEY",
    keyPlaceholder: "sk-...",
    keyLink: "https://platform.openai.com/api-keys",
    freeTier: "Free trial credits available on sign-up",
    hasFreeTier: true,
    models: [
      { value: "gpt-4o-mini", label: "GPT-4o mini ⭐ Recommended (fast & affordable)", free: true },
      { value: "gpt-4o", label: "GPT-4o (most capable)", free: false },
      { value: "gpt-3.5-turbo", label: "GPT-3.5 Turbo (legacy, cheapest)", free: true },
      { value: "gpt-4-turbo", label: "GPT-4 Turbo", free: false },
    ],
  },
  anthropic: {
    label: "Anthropic",
    icon: "🟠",
    keyLabel: "ANTHROPIC_API_KEY",
    keyPlaceholder: "sk-ant-...",
    keyLink: "https://console.anthropic.com/settings/keys",
    freeTier: "Free tier: $5 credit on sign-up",
    hasFreeTier: true,
    models: [
      { value: "claude-3-5-haiku-20241022", label: "Claude 3.5 Haiku ⭐ Recommended (fast & affordable)", free: true },
      { value: "claude-3-5-sonnet-20241022", label: "Claude 3.5 Sonnet (balanced)", free: false },
      { value: "claude-3-opus-20240229", label: "Claude 3 Opus (most capable)", free: false },
      { value: "claude-3-haiku-20240307", label: "Claude 3 Haiku (cheapest)", free: true },
    ],
  },
  google: {
    label: "Google Gemini",
    icon: "🔵",
    keyLabel: "GOOGLE_AI_API_KEY",
    keyPlaceholder: "AIza...",
    keyLink: "https://aistudio.google.com/app/apikey",
    freeTier: "Free tier: Generous free quota (no credit card needed)",
    hasFreeTier: true,
    models: [
      { value: "gemini-2.0-flash", label: "Gemini 2.0 Flash ⭐ Recommended (free tier, fast)", free: true },
      { value: "gemini-1.5-flash", label: "Gemini 1.5 Flash (free tier)", free: true },
      { value: "gemini-1.5-pro", label: "Gemini 1.5 Pro (higher limits)", free: false },
      { value: "gemini-pro", label: "Gemini Pro (legacy)", free: false },
    ],
  },
  openrouter: {
    label: "OpenRouter",
    icon: "🟣",
    keyLabel: "OPENROUTER_API_KEY",
    keyPlaceholder: "sk-or-v1-...",
    keyLink: "https://openrouter.ai/keys",
    freeTier: "Free models available — no credit card required for free tier",
    hasFreeTier: true,
    models: [
      // ── Free models ─────────────────────────────────────────────────────────
      { value: "google/gemma-4-31b-it:free",           label: "Google Gemma 4 31B ⭐ Recommended",     free: true  },
      { value: "meta-llama/llama-4-scout:free",         label: "Meta Llama 4 Scout",                   free: true  },
      { value: "meta-llama/llama-4-maverick:free",      label: "Meta Llama 4 Maverick",                free: true  },
      { value: "deepseek/deepseek-r1:free",             label: "DeepSeek R1 (reasoning)",              free: true  },
      { value: "deepseek/deepseek-v3-base:free",        label: "DeepSeek V3 Base",                     free: true  },
      { value: "qwen/qwen3-8b:free",                    label: "Qwen3 8B",                             free: true  },
      { value: "mistralai/mistral-7b-instruct:free",    label: "Mistral 7B Instruct",                  free: true  },
      { value: "meta-llama/llama-3.1-8b-instruct:free", label: "Meta Llama 3.1 8B Instruct",           free: true  },
      // ── Paid models ─────────────────────────────────────────────────────────
      { value: "deepseek/deepseek-v4-flash",            label: "DeepSeek V4 Flash ⭐ Fast & affordable", free: false },
      { value: "deepseek/deepseek-r1",                  label: "DeepSeek R1 (paid, higher limits)",    free: false },
      { value: "deepseek/deepseek-v3",                  label: "DeepSeek V3",                          free: false },
      { value: "anthropic/claude-3.5-sonnet",           label: "Claude 3.5 Sonnet (via OpenRouter)",   free: false },
      { value: "openai/gpt-4o",                         label: "GPT-4o (via OpenRouter)",              free: false },
      { value: "openai/gpt-4o-mini",                    label: "GPT-4o mini (via OpenRouter)",         free: false },
      { value: "google/gemini-pro-1.5",                 label: "Gemini Pro 1.5 (via OpenRouter)",      free: false },
      { value: "mistralai/mistral-large",               label: "Mistral Large",                        free: false },
      { value: "meta-llama/llama-3.3-70b-instruct",     label: "Llama 3.3 70B Instruct",               free: false },
    ],
  },
} as const;

type AiProvider = keyof typeof AI_PROVIDERS;

const formSchema = z.object({
  name: z.string().min(2, "Company name is required"),
  generalInfo: z.string().optional(),
  systemPrompt: z.string().optional(),
  googleSheetsEnabled: z.boolean().default(false),
  googleSheetsLink: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  googleSheetsName: z.string().optional().or(z.literal("")),
  googleSheetsPage: z.string().optional().or(z.literal("")),
  serviceAccountKey: z.string().optional().or(z.literal("")),
  aiAgentApiKey: z.string().optional().or(z.literal("")),
  aiProvider: z.enum(["openai", "anthropic", "google", "openrouter"]).optional(),
  aiModel: z.string().optional().or(z.literal("")),
  telegramBotApiKey: z.string().optional().or(z.literal("")),
  whatsappApiKey: z.string().optional().or(z.literal("")),
  websiteChatbotKey: z.string().optional().or(z.literal("")),
  websiteDataUrl: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

type QuotaData = { quota: number | null; usedTokens: number; percentUsed: number | null; warning: "ok" | "near" | "exceeded" | "none" };

type ChatMessage = { role: "user" | "bot"; text: string };

function WidgetPreview({ widgetKey, companyName, isActive, hasAi }: {
  widgetKey: string;
  companyName: string;
  isActive: boolean;
  hasAi: boolean;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: "bot", text: `👋 Hi! I'm ${companyName}'s assistant. How can I help you today?` },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [sessionId] = useState(() => "preview_" + Math.random().toString(36).slice(2));
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const reset = useCallback(() => {
    setMessages([{ role: "bot", text: `👋 Hi! I'm ${companyName}'s assistant. How can I help you today?` }]);
    setInput("");
    setLoading(false);
  }, [companyName]);

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", text }]);
    setLoading(true);
    try {
      const res = await fetch(`/api/widget/${encodeURIComponent(widgetKey)}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, sessionId }),
      });
      const data = await res.json();
      setMessages((prev) => [...prev, {
        role: "bot",
        text: data.response ?? (data.error ? `⚠️ ${data.error}` : "⚠️ No response received."),
      }]);
    } catch {
      setMessages((prev) => [...prev, { role: "bot", text: "⚠️ Connection error. Please try again." }]);
    } finally {
      setLoading(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [input, loading, widgetKey, sessionId]);

  const handleKey = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); }
  };

  if (!isActive) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground gap-2">
        <AlertTriangle className="w-8 h-8 text-amber-500" />
        <p className="text-sm font-medium">Company is inactive</p>
        <p className="text-xs">Ask your admin to activate your subscription.</p>
      </div>
    );
  }

  if (!hasAi) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground gap-2">
        <Bot className="w-8 h-8" />
        <p className="text-sm font-medium">AI not configured</p>
        <p className="text-xs">Set up your AI Provider and API Key above, then save.</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[440px] rounded-xl border border-border overflow-hidden bg-background shadow-sm">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 px-4 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center text-white text-lg">🤖</div>
          <div>
            <p className="text-white font-semibold text-sm">{companyName}</p>
            <p className="text-white/80 text-xs flex items-center gap-1.5">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-400"></span>
              Online · AI-powered
            </p>
          </div>
        </div>
        <button
          onClick={reset}
          title="Reset conversation"
          className="text-white/70 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-white/10"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-muted/20">
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
            {m.role === "bot" && (
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-xs shrink-0 mr-2 mt-0.5">🤖</div>
            )}
            <div className={`max-w-[78%] px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
              m.role === "user"
                ? "bg-gradient-to-br from-blue-500 to-indigo-600 text-white rounded-br-sm"
                : "bg-white dark:bg-card border border-border text-foreground rounded-bl-sm shadow-sm"
            }`}>
              {m.text}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start items-end gap-2">
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-xs shrink-0">🤖</div>
            <div className="bg-white dark:bg-card border border-border rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm">
              <div className="flex gap-1 items-center">
                <span className="w-2 h-2 rounded-full bg-muted-foreground/40 animate-bounce" style={{ animationDelay: "0ms" }}></span>
                <span className="w-2 h-2 rounded-full bg-muted-foreground/40 animate-bounce" style={{ animationDelay: "150ms" }}></span>
                <span className="w-2 h-2 rounded-full bg-muted-foreground/40 animate-bounce" style={{ animationDelay: "300ms" }}></span>
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="border-t border-border px-3 py-2.5 flex items-end gap-2 bg-background shrink-0">
        <textarea
          ref={inputRef}
          rows={1}
          value={input}
          onChange={(e) => {
            setInput(e.target.value);
            e.target.style.height = "auto";
            e.target.style.height = Math.min(e.target.scrollHeight, 96) + "px";
          }}
          onKeyDown={handleKey}
          disabled={loading}
          placeholder="Type a message…"
          className="flex-1 resize-none bg-muted/40 rounded-xl border border-border px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/60 disabled:opacity-50 transition-all max-h-24"
        />
        <button
          onClick={send}
          disabled={loading || !input.trim()}
          className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90 transition-opacity shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

export default function ClientCompany() {
  const { data: company, isLoading } = useGetClientCompany();
  type AiStatus = { status: "ok" | "no_key" | "invalid_key" | "quota_exceeded" | "error" | "no_company"; provider?: string; model?: string; detail?: string };
  const { data: aiStatus, isLoading: aiStatusLoading, refetch: refetchAiStatus } = useQuery<AiStatus>({
    queryKey: ["client-ai-status"],
    queryFn: () => customFetch("/api/client/company/ai-status") as Promise<AiStatus>,
    enabled: true,
    staleTime: 60_000,
    retry: false,
  });

  const { data: quotaData } = useQuery<QuotaData>({
    queryKey: ["client-company-quota"],
    queryFn: () => customFetch("/api/client/company/quota") as Promise<QuotaData>,
    enabled: true,
    refetchInterval: 60_000,
  });
  const createCompany = useCreateClientCompany();
  const updateCompany = useUpdateClientCompany();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [copiedWebhook, setCopiedWebhook] = useState(false);
  const [showApiKey, setShowApiKey] = useState(false);
  const [tgRegistering, setTgRegistering] = useState(false);
  const [tgStatus, setTgStatus] = useState<{ ok: boolean; message: string } | null>(null);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const testGoogleSheet = useTestClientGoogleSheetConnection();
  const testingConnection = testGoogleSheet.isPending;
  const initialized = useRef(false);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      generalInfo: "",
      systemPrompt: "",
      googleSheetsEnabled: false,
      googleSheetsLink: "",
      googleSheetsName: "",
      googleSheetsPage: "",
      serviceAccountKey: "",
      aiAgentApiKey: "",
      aiProvider: undefined,
      aiModel: "",
      telegramBotApiKey: "",
      whatsappApiKey: "",
      websiteChatbotKey: "",
      websiteDataUrl: "",
    },
  });

  useEffect(() => {
    if (company && !initialized.current) {
      form.reset({
        name: company.name || "",
        generalInfo: company.generalInfo || "",
        systemPrompt: company.systemPrompt || "",
        googleSheetsEnabled: company.googleSheetsEnabled || false,
        googleSheetsLink: company.googleSheetsLink || "",
        googleSheetsName: company.googleSheetsName || "",
        googleSheetsPage: company.googleSheetsPage || "",
        serviceAccountKey: company.serviceAccountKey || "",
        aiAgentApiKey: company.aiAgentApiKey || "",
        aiProvider: (company.aiProvider as AiProvider) || undefined,
        aiModel: company.aiModel || "",
        telegramBotApiKey: company.telegramBotApiKey || "",
        whatsappApiKey: company.whatsappApiKey || "",
        websiteChatbotKey: company.websiteChatbotKey || "",
        websiteDataUrl: company.websiteDataUrl || "",
      });
      initialized.current = true;
    }
  }, [company, form]);

  const onSubmit = (values: z.infer<typeof formSchema>) => {
    // Transform empty strings to nulls for API
    const data = {
      ...values,
      googleSheetsLink: values.googleSheetsLink || null,
      googleSheetsName: values.googleSheetsName || null,
      googleSheetsPage: values.googleSheetsPage || null,
      serviceAccountKey: values.serviceAccountKey || null,
      aiAgentApiKey: values.aiAgentApiKey || null,
      aiProvider: values.aiProvider || null,
      aiModel: values.aiModel || null,
      telegramBotApiKey: values.telegramBotApiKey || null,
      whatsappApiKey: values.whatsappApiKey || null,
      websiteChatbotKey: values.websiteChatbotKey || null,
      websiteDataUrl: values.websiteDataUrl || null,
    };

    if (company) {
      updateCompany.mutate({ data }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetClientCompanyQueryKey() });
          toast({ title: "Configuration saved successfully" });
        },
        onError: (error: any) => {
          toast({ title: "Failed to save", description: error.message, variant: "destructive" });
        }
      });
    } else {
      createCompany.mutate({ data }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetClientCompanyQueryKey() });
          toast({ title: "Company configured successfully" });
        },
        onError: (error: any) => {
          toast({ title: "Failed to create", description: error.message, variant: "destructive" });
        }
      });
    }
  };

  const copyToClipboard = () => {
    if (!company) return;
    const code = `<script src="https://chatbot.example.com/widget.js" data-company="${company.id}"></script>`;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copied to clipboard" });
  };

  const webhookUrl = `${window.location.origin}/api/webhook/message`;
  const webhookPhase1Example = (channel: string, key: string) =>
    JSON.stringify({ apiKey: key || "<your-channel-key>", channel, sessionId: "user_123", customerMessage: "What are your opening hours?" }, null, 2);

  const webhookResponseExample = JSON.stringify({
    id: 42,
    companyId: 1,
    channel: "website",
    sessionId: "user_123",
    createdAt: new Date().toISOString(),
    systemPrompt: "You are a helpful assistant for Acme Corp...",
    conversationHistory: [
      { role: "user", content: "Hi there!" },
      { role: "assistant", content: "Hello! How can I help you today?" },
    ],
  }, null, 2);

  const webhookPhase2Example = (channel: string, key: string) =>
    JSON.stringify({ apiKey: key || "<your-channel-key>", channel, sessionId: "user_123", customerMessage: "What are your opening hours?", botResponse: "We are open Monday–Friday, 9 am–6 pm." }, null, 2);

  const copyWebhookUrl = () => {
    navigator.clipboard.writeText(webhookUrl);
    setCopiedWebhook(true);
    setTimeout(() => setCopiedWebhook(false), 2000);
    toast({ title: "Webhook URL copied" });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <Card className="bg-card">
          <CardHeader><Skeleton className="h-6 w-32" /></CardHeader>
          <CardContent className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-10 w-32" />
          </CardContent>
        </Card>
      </div>
    );
  }

  const isSaving = createCompany.isPending || updateCompany.isPending;

  const handleTestConnection = async () => {
    setTestResult(null);
    const googleSheetsLink = form.getValues("googleSheetsLink");
    const googleSheetsPage = form.getValues("googleSheetsPage");
    if (!googleSheetsLink) return;

    if (!company) {
      setTestResult({
        success: false,
        message: "Save your configuration first, then test the connection.",
      });
      return;
    }

    try {
      const result = await testGoogleSheet.mutateAsync({
        data: { googleSheetsLink, googleSheetsPage: googleSheetsPage || undefined },
      });
      setTestResult(result);
    } catch (err) {
      const message =
        (err && typeof err === "object" && "data" in err && err.data && typeof err.data === "object" && "error" in (err.data as Record<string, unknown>)
          ? String((err.data as Record<string, unknown>).error)
          : undefined) ||
        (err instanceof Error ? err.message : undefined) ||
        "Connection error. Check the sheet URL and try again.";
      setTestResult({ success: false, message });
    }
  };

  const registerTelegramWebhook = async () => {
    if (!company?.telegramBotApiKey) return;
    setTgRegistering(true);
    setTgStatus(null);
    const webhookUrl = `${window.location.origin}/api/telegram/webhook/${company.telegramBotApiKey}`;
    try {
      const res = await fetch(`/api/telegram/register-webhook/${company.telegramBotApiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ webhookUrl }),
      });
      const data = await res.json();
      if (res.ok) {
        setTgStatus({ ok: true, message: "✅ Webhook registered! Telegram will now send messages to your chatbot." });
      } else {
        setTgStatus({ ok: false, message: `❌ ${data.error}` });
      }
    } catch {
      setTgStatus({ ok: false, message: "❌ Connection error. Check your bot token and try again." });
    } finally {
      setTgRegistering(false);
    }
  };

  const showQuotaBanner = quotaData && quotaData.warning !== "none" && quotaData.warning !== "ok";

  return (
    <div className="space-y-8 max-w-4xl pb-12">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Configuration</h1>
        <p className="text-muted-foreground mt-2">Manage your AI chatbot parameters and integrations.</p>
      </div>

      {company && !company.isActive && (
        <div className="flex items-start gap-3 rounded-xl border border-red-500/40 bg-red-500/10 px-4 py-4 text-sm">
          <AlertTriangle className="w-5 h-5 text-red-500 mt-0.5 shrink-0" />
          <div className="space-y-1">
            <p className="font-semibold text-red-600 dark:text-red-400">Chatbot is inactive — contact your admin</p>
            <p className="text-red-600/80 dark:text-red-400/80">
              Your subscription has not been activated yet. All channels (Telegram, WhatsApp, Website Widget) will not respond to messages until an admin activates your account.
            </p>
          </div>
        </div>
      )}

      {/* AI Key Status Indicator */}
      {company && (
        <div className="space-y-2">
        <div className={`flex items-center justify-between gap-3 rounded-xl border px-4 py-3 text-sm transition-all ${
          aiStatusLoading ? "border-border bg-muted/30" :
          aiStatus?.status === "ok" ? "border-emerald-500/40 bg-emerald-500/8" :
          aiStatus?.status === "no_key" ? "border-amber-500/40 bg-amber-500/8" :
          aiStatus?.status === "quota_exceeded" ? "border-orange-500/40 bg-orange-500/8" :
          aiStatus?.status === "invalid_key" ? "border-red-500/40 bg-red-500/8" :
          "border-border bg-muted/30"
        }`}>
          <div className="flex items-center gap-3">
            {aiStatusLoading ? (
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-muted-foreground/30 animate-pulse" />
            ) : aiStatus?.status === "ok" ? (
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-[0_0_6px_2px_rgba(16,185,129,0.4)]" />
            ) : aiStatus?.status === "quota_exceeded" ? (
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-orange-500" />
            ) : aiStatus?.status === "invalid_key" ? (
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-red-500" />
            ) : aiStatus?.status === "no_key" ? (
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-amber-500" />
            ) : (
              <span className="inline-block w-2.5 h-2.5 rounded-full bg-muted-foreground/40" />
            )}
            <div>
              <span className="font-medium">
                {aiStatusLoading ? "Checking AI connection…" :
                 aiStatus?.status === "ok" ? "AI is connected and working" :
                 aiStatus?.status === "quota_exceeded" ? "Quota exceeded — API rate limit reached" :
                 aiStatus?.status === "invalid_key" ? "Invalid API key — authentication failed" :
                 aiStatus?.status === "no_key" ? "No AI API key configured" :
                 "AI status unknown"}
              </span>
              {!aiStatusLoading && aiStatus?.model && (
                <span className="ml-2 text-xs text-muted-foreground font-mono">
                  {aiStatus.provider} / {aiStatus.model}
                </span>
              )}
              {aiStatus?.status === "quota_exceeded" && (
                <p className="text-xs text-orange-600 dark:text-orange-400 mt-0.5">
                  Your API key has hit its free tier limit. Enable billing or use a new key in the AI Configuration section below.
                </p>
              )}
              {aiStatus?.status === "invalid_key" && (
                <p className="text-xs text-red-600 dark:text-red-400 mt-0.5">
                  The API key saved is rejected by the AI provider. Update it in the AI Configuration section below.
                </p>
              )}
              {aiStatus?.status === "no_key" && (
                <p className="text-xs text-amber-600 dark:text-amber-400 mt-0.5">
                  Add an API key in the AI Configuration section below to activate your chatbot.
                </p>
              )}
            </div>
          </div>
          <Button
            type="button" variant="ghost" size="sm"
            className="shrink-0 h-7 px-2 text-xs"
            onClick={() => refetchAiStatus()}
            disabled={aiStatusLoading}
          >
            <RotateCcw className={`w-3 h-3 mr-1 ${aiStatusLoading ? "animate-spin" : ""}`} />
            Recheck
          </Button>
        </div>
      
        {/* Color legend */}
      
        <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 px-1">
          <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_5px_1px_rgba(16,185,129,0.5)]" />
            متصل ويعمل
          </span>
          <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-500" />
            لا يوجد API Key
          </span>
          <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <span className="inline-block w-2 h-2 rounded-full bg-orange-500" />
            تجاوز الحصة المجانية
          </span>
          <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <span className="inline-block w-2 h-2 rounded-full bg-red-500" />
            مفتاح خاطئ أو منتهي
          </span>
          <span className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <span className="inline-block w-2 h-2 rounded-full bg-muted-foreground/40" />
            حالة غير معروفة
          </span>
        </div>
        </div>
      )}

      {showQuotaBanner && quotaData && (
        <div className={`flex items-start gap-3 rounded-lg border px-4 py-3 text-sm ${
          quotaData.warning === "exceeded"
            ? "bg-red-500/10 border-red-500/30 text-red-600 dark:text-red-400"
            : "bg-amber-500/10 border-amber-500/30 text-amber-700 dark:text-amber-400"
        }`}>
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <div className="space-y-0.5">
            {quotaData.warning === "exceeded" ? (
              <>
                <p className="font-semibold">Monthly token quota exceeded</p>
                <p className="opacity-80">
                  You have used <strong>{quotaData.usedTokens.toLocaleString()}</strong> of your <strong>{quotaData.quota!.toLocaleString()}</strong> token quota this month ({quotaData.percentUsed}%). New chatbot messages may be blocked until the next billing cycle.
                </p>
              </>
            ) : (
              <>
                <p className="font-semibold">Approaching monthly token quota</p>
                <p className="opacity-80">
                  You have used <strong>{quotaData.usedTokens.toLocaleString()}</strong> of your <strong>{quotaData.quota!.toLocaleString()}</strong> token quota this month ({quotaData.percentUsed}%). Consider upgrading or reducing usage.
                </p>
              </>
            )}
          </div>
          <div className="ml-auto flex items-center gap-1 shrink-0 text-xs font-medium">
            <Gauge className="w-3.5 h-3.5" />
            {quotaData.percentUsed}%
          </div>
        </div>
      )}

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          
          <Card className="bg-card border-border/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="w-5 h-5 text-primary" />
                General Information
              </CardTitle>
              <CardDescription>Core identity of your chatbot.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company Name <span className="text-destructive">*</span></FormLabel>
                    <FormControl>
                      <Input {...field} className="bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="generalInfo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Knowledge Base / General Info</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        className="bg-background min-h-[120px]" 
                        placeholder="Provide background information about your company..."
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="systemPrompt"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>System Prompt</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field} 
                        className="bg-background font-mono text-sm min-h-[160px]" 
                        placeholder="You are a helpful customer support assistant for..."
                      />
                    </FormControl>
                    <FormDescription>
                      Instructions that dictate the persona and behavior of your AI agent.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="websiteDataUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Website Data URL</FormLabel>
                    <FormControl>
                      <Input {...field} className="bg-background" placeholder="https://..." />
                    </FormControl>
                    <FormDescription>
                      Optional URL to scrape for additional knowledge.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          <Accordion type="multiple" className="w-full space-y-4" defaultValue={["integrations"]}>
            
            <AccordionItem value="integrations" className="bg-card border border-border/50 rounded-lg px-1">
              <AccordionTrigger className="hover:no-underline px-4 py-4">
                <div className="flex items-center gap-2 font-semibold">
                  <Bot className="w-5 h-5 text-primary" />
                  AI Agent & Integrations
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-6 space-y-6">

                {/* Channels */}
                <div className="space-y-3">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-2 border-b border-border/50 pb-2">
                    <MessageCircle className="w-3.5 h-3.5" /> Channels
                  </h4>
                  <div className="grid md:grid-cols-3 gap-4">
                    <FormField control={form.control} name="telegramBotApiKey" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Telegram Bot Token</FormLabel>
                        <FormControl><PasswordInput {...field} className="bg-background" placeholder="••••••••" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="whatsappApiKey" render={({ field }) => (
                      <FormItem>
                        <FormLabel>WhatsApp API Key</FormLabel>
                        <FormControl><PasswordInput {...field} className="bg-background" placeholder="••••••••" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                    <FormField control={form.control} name="websiteChatbotKey" render={({ field }) => (
                      <FormItem>
                        <FormLabel>Website Widget Key</FormLabel>
                        <FormControl><PasswordInput {...field} className="bg-background" placeholder="••••••••" /></FormControl>
                        <FormMessage />
                      </FormItem>
                    )} />
                  </div>
                </div>

                {/* AI Provider & Model */}
                <div className="space-y-4">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-2 border-b border-border/50 pb-2">
                    <Lock className="w-3.5 h-3.5" /> AI Provider &amp; Model
                  </h4>

                  {/* Step 1: Choose Provider */}
                  <div className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground">1. Choose AI Provider</p>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {(Object.entries(AI_PROVIDERS) as [AiProvider, typeof AI_PROVIDERS[AiProvider]][]).map(([key, p]) => {
                        const selected = form.watch("aiProvider") === key;
                        const freeModels = p.models.filter((m) => m.free).length;
                        const paidModels = p.models.filter((m) => !m.free).length;
                        return (
                          <button
                            key={key}
                            type="button"
                            onClick={() => {
                              form.setValue("aiProvider", key);
                              form.setValue("aiModel", "");
                            }}
                            className={`flex flex-col items-center gap-1.5 rounded-lg border px-3 py-3 text-xs font-medium transition-all ${
                              selected
                                ? "border-primary bg-primary/10 text-primary"
                                : "border-border bg-background text-muted-foreground hover:border-primary/50 hover:text-foreground"
                            }`}
                          >
                            <span className="text-lg">{p.icon}</span>
                            <span>{p.label}</span>
                            {freeModels > 0 && paidModels === 0 ? (
                              <span className="text-[10px] text-green-500 font-normal">Free tier ✓</span>
                            ) : freeModels > 0 ? (
                              <span className="text-[10px] text-green-500 font-normal">{freeModels} free models</span>
                            ) : (
                              <span className="text-[10px] text-muted-foreground font-normal">Paid</span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Free tier notice */}
                  {form.watch("aiProvider") && (
                    <div className="flex items-start gap-2 rounded-lg bg-green-500/10 border border-green-500/20 px-3 py-2.5 animate-in fade-in duration-200">
                      <span className="text-green-500 text-sm shrink-0">✓</span>
                      <div className="space-y-0.5">
                        <p className="text-xs font-medium text-green-600 dark:text-green-400">
                          {AI_PROVIDERS[form.watch("aiProvider") as AiProvider]?.freeTier}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Get your free API key at{" "}
                          <a
                            href={AI_PROVIDERS[form.watch("aiProvider") as AiProvider]?.keyLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-primary underline hover:no-underline"
                          >
                            {AI_PROVIDERS[form.watch("aiProvider") as AiProvider]?.keyLink?.replace("https://", "")}
                          </a>
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Step 2: Choose Model */}
                  {form.watch("aiProvider") && (() => {
                    const provider = form.watch("aiProvider") as AiProvider;
                    const allModels = AI_PROVIDERS[provider]?.models ?? [];
                    const freeModels = allModels.filter((m) => m.free);
                    const paidModels = allModels.filter((m) => !m.free);
                    const hasBoth = freeModels.length > 0 && paidModels.length > 0;
                    const currentModel = form.watch("aiModel") || "";
                    const currentIsFree = freeModels.some((m) => m.value === currentModel);
                    const currentIsPaid = paidModels.some((m) => m.value === currentModel);

                    if (hasBoth) {
                      return (
                        <div className="space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
                          <p className="text-xs font-medium text-muted-foreground">2. Choose Model</p>

                          {/* Free models dropdown */}
                          <div className="space-y-1.5">
                            <p className="text-[11px] font-semibold text-green-600 dark:text-green-400 flex items-center gap-1.5">
                              🆓 Free Models
                            </p>
                            <div className="flex items-center gap-1.5">
                              <Select
                                value={currentIsFree ? currentModel : ""}
                                onValueChange={(val) => form.setValue("aiModel", val)}
                              >
                                <SelectTrigger className="bg-background border-green-500/30 focus:ring-green-500/30 flex-1">
                                  <SelectValue placeholder="Select a free model..." />
                                </SelectTrigger>
                                <SelectContent>
                                  {freeModels.map((m) => (
                                    <SelectItem key={m.value} value={m.value}>
                                      <span className="flex items-center gap-2">
                                        {m.label}
                                        <span className="text-[10px] font-semibold text-green-600 dark:text-green-400 bg-green-500/10 border border-green-500/30 rounded px-1 py-0.5 leading-none">FREE</span>
                                      </span>
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              {currentIsFree && (
                                <button
                                  type="button"
                                  onClick={() => form.setValue("aiModel", "")}
                                  className="shrink-0 rounded-md p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                                  aria-label="Clear free model selection"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Paid models dropdown */}
                          <div className="space-y-1.5">
                            <p className="text-[11px] font-semibold text-muted-foreground flex items-center gap-1.5">
                              💳 Paid Models
                            </p>
                            <div className="flex items-center gap-1.5">
                              <Select
                                value={currentIsPaid ? currentModel : ""}
                                onValueChange={(val) => form.setValue("aiModel", val)}
                              >
                                <SelectTrigger className="bg-background flex-1">
                                  <SelectValue placeholder="Select a paid model..." />
                                </SelectTrigger>
                                <SelectContent>
                                  {paidModels.map((m) => (
                                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              {currentIsPaid && (
                                <button
                                  type="button"
                                  onClick={() => form.setValue("aiModel", "")}
                                  className="shrink-0 rounded-md p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
                                  aria-label="Clear paid model selection"
                                >
                                  <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                </button>
                              )}
                            </div>
                          </div>

                          {form.formState.errors.aiModel && (
                            <p className="text-sm font-medium text-destructive">{form.formState.errors.aiModel.message}</p>
                          )}
                        </div>
                      );
                    }

                    return (
                      <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-200">
                        <p className="text-xs font-medium text-muted-foreground">2. Choose Model</p>
                        <FormField
                          control={form.control}
                          name="aiModel"
                          render={({ field }) => (
                            <FormItem>
                              <Select value={field.value || ""} onValueChange={field.onChange}>
                                <FormControl>
                                  <SelectTrigger className="bg-background">
                                    <SelectValue placeholder="Select a model..." />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  {allModels.map((m) => (
                                    <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    );
                  })()}

                  {/* Step 3: API Key */}
                  {form.watch("aiProvider") && (
                    <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-200">
                      <p className="text-xs font-medium text-muted-foreground">3. API Key</p>
                      {!form.watch("aiAgentApiKey") ? (
                        <div className="rounded-xl border border-border/60 bg-background overflow-hidden">
                          <div className="p-4 space-y-1.5">
                            <p className="text-sm font-medium">Enter your API key</p>
                            <p className="text-xs text-muted-foreground leading-relaxed">
                              Your {AI_PROVIDERS[form.watch("aiProvider") as AiProvider]?.label} API key is used server-side to generate AI responses.
                              It is stored securely and never exposed to end users.
                            </p>
                          </div>
                          <div className="border-t border-border/50 bg-muted/30 px-4 py-3 space-y-2">
                            <p className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
                              <Lock className="w-3 h-3" /> Secrets
                            </p>
                            <FormField
                              control={form.control}
                              name="aiAgentApiKey"
                              render={({ field }) => (
                                <FormItem>
                                  <div className="flex items-center rounded-lg border border-border bg-background overflow-hidden">
                                    <div className="px-3 py-2.5 bg-muted/50 border-r border-border shrink-0">
                                      <span className="font-mono text-xs text-muted-foreground">
                                        {AI_PROVIDERS[form.watch("aiProvider") as AiProvider]?.keyLabel}
                                      </span>
                                    </div>
                                    <FormControl>
                                      <div className="flex-1 flex items-center pr-2">
                                        <Input
                                          type={showApiKey ? "text" : "password"}
                                          {...field}
                                          className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 font-mono text-sm h-9"
                                          placeholder={AI_PROVIDERS[form.watch("aiProvider") as AiProvider]?.keyPlaceholder}
                                        />
                                        <button type="button" onClick={() => setShowApiKey(!showApiKey)} className="text-muted-foreground hover:text-foreground p-1 shrink-0">
                                          {showApiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                        </button>
                                        <div className="ml-1 w-7 h-7 rounded-md bg-muted/50 border border-border flex items-center justify-center shrink-0">
                                          <UserRound className="w-3.5 h-3.5 text-muted-foreground" />
                                        </div>
                                      </div>
                                    </FormControl>
                                  </div>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                        </div>
                      ) : (
                        <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 overflow-hidden">
                          <div className="border-b border-emerald-500/20 px-4 py-2.5 flex items-center justify-between">
                            <p className="text-xs font-semibold text-emerald-500 flex items-center gap-1.5">
                              <Lock className="w-3 h-3" /> Secrets
                            </p>
                            <span className="text-xs text-emerald-500 font-medium">✓ Configured</span>
                          </div>
                          <div className="px-4 py-3 space-y-2">
                            <div className="flex items-center rounded-lg border border-emerald-500/20 bg-background overflow-hidden">
                              <div className="px-3 py-2.5 bg-muted/50 border-r border-border shrink-0">
                                <span className="font-mono text-xs text-muted-foreground">
                                  {AI_PROVIDERS[form.watch("aiProvider") as AiProvider]?.keyLabel ?? "API_KEY"}
                                </span>
                              </div>
                              <FormField
                                control={form.control}
                                name="aiAgentApiKey"
                                render={({ field }) => (
                                  <FormItem className="flex-1">
                                    <FormControl>
                                      <div className="flex items-center pr-2">
                                        <Input type={showApiKey ? "text" : "password"} {...field} className="border-0 bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 font-mono text-sm h-9" />
                                        <button type="button" onClick={() => setShowApiKey(!showApiKey)} className="text-muted-foreground hover:text-foreground p-1 shrink-0">
                                          {showApiKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                                        </button>
                                      </div>
                                    </FormControl>
                                  </FormItem>
                                )}
                              />
                            </div>
                            <p className="text-xs text-emerald-600 dark:text-emerald-400">
                              ✓ AI auto-responses are active using {AI_PROVIDERS[form.watch("aiProvider") as AiProvider]?.label ?? "AI"} — {form.watch("aiModel") || "default model"}.
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {!form.watch("aiProvider") && (
                    <p className="text-xs text-muted-foreground">
                      Select a provider above to configure AI-powered auto-responses on the webhook.
                    </p>
                  )}
                </div>

                {/* Secrets */}
                <div className="space-y-3">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-2 border-b border-border/50 pb-2">
                    <KeyRound className="w-3.5 h-3.5" /> Channel Secrets
                  </h4>
                  <div className="rounded-lg border border-border/60 bg-background divide-y divide-border/40">
                    {[
                      { label: "Telegram Bot Token", field: "telegramBotApiKey" as const, value: form.watch("telegramBotApiKey") },
                      { label: "WhatsApp API Key",   field: "whatsappApiKey"   as const, value: form.watch("whatsappApiKey") },
                      { label: "Website Widget Key", field: "websiteChatbotKey" as const, value: form.watch("websiteChatbotKey") },
                    ].map(({ label, value }) => (
                      <div key={label} className="flex items-center justify-between px-4 py-3 text-sm">
                        <span className="text-muted-foreground">{label}</span>
                        <span className="font-mono text-xs tracking-widest">
                          {value ? "••••••••" + value.slice(-4) : <span className="text-muted-foreground/50 not-italic">not set</span>}
                        </span>
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    These keys are stored encrypted and never exposed after saving. Update them in the Channels section above.
                  </p>
                </div>

              </AccordionContent>
            </AccordionItem>

            <AccordionItem value="sheets" className="bg-card border border-border/50 rounded-lg px-1">
              <AccordionTrigger className="hover:no-underline px-4 py-4">
                <div className="flex items-center gap-2 font-semibold">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-500" />
                  Google Sheets Integration
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-4 space-y-4">
                <FormField
                  control={form.control}
                  name="googleSheetsEnabled"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border border-border p-4 bg-background">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Enable Sheets Sync</FormLabel>
                        <FormDescription>
                          Automatically log data and interactions to a Google Sheet.
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                
                {form.watch("googleSheetsEnabled") && (
                  <div className="space-y-4 pt-4 border-t border-border mt-4 animate-in fade-in slide-in-from-top-4 duration-300">
                    <FormField
                      control={form.control}
                      name="googleSheetsLink"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Google Sheet URL</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              className="bg-background"
                              placeholder="https://docs.google.com/spreadsheets/d/..."
                              onChange={(e) => { field.onChange(e); setTestResult(null); }}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="googleSheetsName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Sheet Name</FormLabel>
                          <FormControl><Input {...field} className="bg-background" placeholder="e.g. Q1 Leads Tracker" /></FormControl>
                          <FormDescription>A friendly label for this spreadsheet (for your own reference).</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="googleSheetsPage"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Page</FormLabel>
                          <FormControl>
                            <Input
                              {...field}
                              className="bg-background"
                              placeholder="e.g. Leads or Sheet1"
                              onChange={(e) => { field.onChange(e); setTestResult(null); }}
                            />
                          </FormControl>
                          <FormDescription>The tab (page) inside the spreadsheet to sync with.</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="serviceAccountKey"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Service Account JSON</FormLabel>
                          <FormControl>
                            <Textarea 
                              {...field} 
                              className="bg-background font-mono text-xs min-h-[100px]" 
                              placeholder='{"type": "service_account", "project_id": "...", ...}'
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <div className="space-y-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleTestConnection}
                        disabled={testingConnection || !form.watch("googleSheetsLink")}
                        className={
                          testResult?.success
                            ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-600 hover:bg-emerald-500/20 hover:text-emerald-600 dark:text-emerald-400 dark:hover:text-emerald-400"
                            : testResult && !testResult.success
                            ? "border-destructive/50 text-destructive hover:bg-destructive/10 hover:text-destructive"
                            : undefined
                        }
                      >
                        {testingConnection ? (
                          "Testing…"
                        ) : testResult?.success ? (
                          <span className="flex items-center gap-1.5"><Check className="h-3.5 w-3.5" /> Connected</span>
                        ) : (
                          "Test Connection"
                        )}
                      </Button>
                      {!company && !testResult && (
                        <p className="text-xs text-muted-foreground">
                          Save your configuration first so we can test the connection.
                        </p>
                      )}
                      {testResult && (
                        <p className={`text-xs rounded-lg border p-2.5 ${
                          testResult.success
                            ? "border-emerald-500/40 bg-emerald-500/5 text-emerald-600 dark:text-emerald-400"
                            : "border-destructive/40 bg-destructive/5 text-destructive"
                        }`}>
                          {testResult.message}
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </AccordionContent>
            </AccordionItem>
          </Accordion>

          <div className="flex justify-end pt-4 sticky bottom-6 z-10">
            <div className="bg-background/80 backdrop-blur-md p-2 rounded-full border border-border shadow-lg inline-block">
              <Button type="submit" size="lg" className="px-8 rounded-full shadow-[0_0_15px_rgba(var(--primary),0.3)]" disabled={isSaving}>
                {isSaving ? "Saving..." : "Save Configuration"}
              </Button>
            </div>
          </div>
        </form>
      </Form>

      {company && company.telegramBotApiKey && (
        <Card className="bg-card border-border/50 border-sky-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <span className="text-lg">✈️</span> Telegram Bot Setup
            </CardTitle>
            <CardDescription>
              Your bot token is saved. You need to register the webhook once so Telegram knows where to send messages.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!company.isActive && (
              <div className="flex items-center gap-2 rounded-lg bg-amber-500/10 border border-amber-500/30 px-3 py-2.5 text-xs text-amber-600 dark:text-amber-400">
                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                Activate your account first before registering — inactive bots will not reply.
              </div>
            )}

            <div className="space-y-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Your Telegram Webhook URL</p>
              <div className="relative group">
                <pre className="bg-muted/40 border border-border rounded-lg px-4 py-2.5 font-mono text-xs overflow-x-auto">
                  {`${window.location.origin}/api/telegram/webhook/${company.telegramBotApiKey}`}
                </pre>
                <Button
                  type="button" variant="ghost" size="sm"
                  className="absolute top-1.5 right-1.5 h-7 px-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => {
                    navigator.clipboard.writeText(`${window.location.origin}/api/telegram/webhook/${company.telegramBotApiKey}`);
                    toast({ title: "Copied!", description: "Webhook URL copied to clipboard." });
                  }}
                >
                  <Copy className="w-3 h-3 mr-1" /> Copy
                </Button>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
              <Button
                type="button"
                onClick={registerTelegramWebhook}
                disabled={tgRegistering || !company.isActive}
                className="bg-sky-500 hover:bg-sky-600 text-white gap-2"
                size="sm"
              >
                {tgRegistering ? (
                  <><span className="animate-spin inline-block w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full" /> Registering…</>
                ) : (
                  <><Zap className="w-3.5 h-3.5" /> Register Webhook with Telegram</>
                )}
              </Button>
              <p className="text-xs text-muted-foreground">
                Click once — this tells Telegram to forward all bot messages to your chatbot.
              </p>
            </div>

            {tgStatus && (
              <div className={`rounded-lg border px-3 py-2.5 text-sm ${tgStatus.ok ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "border-red-500/30 bg-red-500/10 text-red-600 dark:text-red-400"}`}>
                {tgStatus.message}
              </div>
            )}

            <div className="rounded-lg border border-border/50 bg-muted/20 p-3 space-y-1.5">
              <p className="text-xs font-semibold text-muted-foreground">How it works after registration:</p>
              <div className="flex flex-col gap-1 text-xs text-muted-foreground">
                <span>① User sends a message to your Telegram bot</span>
                <span>② Telegram forwards it to your server automatically</span>
                <span>③ AI reads your System Prompt + Website Data and replies</span>
                <span>④ Response is sent back to the user in Telegram</span>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {company && (
        <Card className="bg-card border-border/50 border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="w-5 h-5 text-primary" />
              How It All Works
            </CardTitle>
            <CardDescription>
              Everything you configure here powers your chatbot across all channels.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* Architecture flow */}
            <div className="rounded-xl border border-border/60 bg-muted/20 p-4 space-y-3">
              {/* Row 1: Inputs */}
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Knowledge Sources</p>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className={`rounded-lg border p-2.5 space-y-1 ${company.systemPrompt ? "border-primary/40 bg-primary/5" : "border-border/40 bg-background"}`}>
                  <div className="text-base">📝</div>
                  <div className="font-medium">System Prompt</div>
                  <div className={`text-[10px] ${company.systemPrompt ? "text-primary" : "text-muted-foreground"}`}>
                    {company.systemPrompt ? "✓ Configured" : "Not set"}
                  </div>
                </div>
                <div className={`rounded-lg border p-2.5 space-y-1 ${company.websiteDataUrl ? "border-primary/40 bg-primary/5" : "border-border/40 bg-background"}`}>
                  <div className="text-base">🌐</div>
                  <div className="font-medium">Website Data URL</div>
                  <div className={`text-[10px] ${company.websiteDataUrl ? "text-primary" : "text-muted-foreground"}`}>
                    {company.websiteDataUrl ? "✓ Configured" : "Not set"}
                  </div>
                </div>
                <div className={`rounded-lg border p-2.5 space-y-1 ${company.googleSheetsEnabled ? "border-emerald-500/40 bg-emerald-500/5" : "border-border/40 bg-background"}`}>
                  <div className="text-base">📊</div>
                  <div className="font-medium">Google Sheets</div>
                  <div className={`text-[10px] ${company.googleSheetsEnabled ? "text-emerald-500" : "text-muted-foreground"}`}>
                    {company.googleSheetsEnabled ? "✓ Enabled" : "Disabled"}
                  </div>
                </div>
              </div>

              {/* Arrow */}
              <div className="flex justify-center text-muted-foreground text-lg">↓</div>

              {/* AI Engine */}
              <div className={`rounded-lg border p-3 flex items-center gap-3 ${company.aiAgentApiKey && company.aiProvider ? "border-primary/40 bg-primary/5" : "border-amber-500/40 bg-amber-500/5"}`}>
                <span className="text-2xl">🤖</span>
                <div className="flex-1">
                  <p className="text-sm font-semibold">AI Engine</p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {company.aiProvider && company.aiModel
                      ? `${company.aiProvider.toUpperCase()} · ${company.aiModel}`
                      : company.aiAgentApiKey
                      ? "Provider not selected"
                      : "⚠️ No API key — configure AI Provider above"}
                  </p>
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${company.aiAgentApiKey && company.aiProvider ? "bg-primary/10 text-primary" : "bg-amber-500/10 text-amber-600"}`}>
                  {company.aiAgentApiKey && company.aiProvider ? "Active" : "Needs setup"}
                </span>
              </div>

              {/* Arrow */}
              <div className="flex justify-center text-muted-foreground text-lg">↓</div>

              {/* Channels */}
              <p className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-1">Channels</p>
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className={`rounded-lg border p-2.5 space-y-1 ${company.telegramBotApiKey ? "border-sky-500/40 bg-sky-500/5" : "border-border/40 bg-background"}`}>
                  <div className="text-base">✈️</div>
                  <div className="font-medium">Telegram</div>
                  <div className={`text-[10px] ${company.telegramBotApiKey ? "text-sky-500" : "text-muted-foreground"}`}>
                    {company.telegramBotApiKey ? "✓ Active" : "Not set"}
                  </div>
                </div>
                <div className={`rounded-lg border p-2.5 space-y-1 ${company.whatsappApiKey ? "border-green-500/40 bg-green-500/5" : "border-border/40 bg-background"}`}>
                  <div className="text-base">💬</div>
                  <div className="font-medium">WhatsApp</div>
                  <div className={`text-[10px] ${company.whatsappApiKey ? "text-green-500" : "text-muted-foreground"}`}>
                    {company.whatsappApiKey ? "✓ Active" : "Not set"}
                  </div>
                </div>
                <div className={`rounded-lg border p-2.5 space-y-1 ${company.websiteChatbotKey ? "border-violet-500/40 bg-violet-500/5" : "border-border/40 bg-background"}`}>
                  <div className="text-base">🌐</div>
                  <div className="font-medium">Website Widget</div>
                  <div className={`text-[10px] ${company.websiteChatbotKey ? "text-violet-500" : "text-muted-foreground"}`}>
                    {company.websiteChatbotKey ? "✓ Ready to embed" : "No key set"}
                  </div>
                </div>
              </div>
            </div>

            {/* Embed code */}
            {company.websiteChatbotKey ? (
              <div className="space-y-2">
                <p className="text-sm font-semibold flex items-center gap-2">
                  <span className="text-violet-500">🌐</span> Website Widget Embed Code
                </p>
                <p className="text-xs text-muted-foreground">
                  Paste this tag anywhere in your website's HTML — it creates a floating chat button automatically.
                </p>
                <div className="relative group">
                  <pre className="bg-background text-foreground p-4 rounded-lg overflow-x-auto border border-violet-500/30 font-mono text-xs leading-relaxed shadow-inner">
{`<script
  src="${window.location.origin}/widget.js"
  data-key="${company.websiteChatbotKey}"
></script>`}
                  </pre>
                  <Button
                    type="button"
                    variant="secondary"
                    size="sm"
                    className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => {
                      navigator.clipboard.writeText(
                        `<script\n  src="${window.location.origin}/widget.js"\n  data-key="${company.websiteChatbotKey}"\n></script>`
                      );
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2000);
                    }}
                  >
                    {copied ? <Check className="w-4 h-4 mr-1.5 text-emerald-500" /> : <Copy className="w-4 h-4 mr-1.5" />}
                    {copied ? "Copied!" : "Copy"}
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                  <span className="inline-block w-2 h-2 rounded-full bg-violet-500"></span>
                  The widget reads your System Prompt, Website Data, and AI settings — fully automatic.
                </p>
              </div>
            ) : (
              <div className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-4 text-sm text-amber-600 dark:text-amber-400">
                ⚠️ Set a <strong>Website Widget Key</strong> in the Channels section above to generate your embed code.
              </div>
            )}

          </CardContent>
        </Card>
      )}

      {company && company.websiteChatbotKey && (
        <Card className="bg-card border-border/50 border-violet-500/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Bot className="w-5 h-5 text-violet-500" />
              Live Widget Preview
            </CardTitle>
            <CardDescription>
              Test your chatbot exactly as your customers will experience it. Uses your real AI configuration — responses are saved to chat history.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <WidgetPreview
              widgetKey={company.websiteChatbotKey}
              companyName={company.name}
              isActive={company.isActive}
              hasAi={!!(company.aiAgentApiKey && company.aiProvider)}
            />
          </CardContent>
        </Card>
      )}

      {company && (
        <Card className="bg-card border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              Webhook & Conversation History
            </CardTitle>
            <CardDescription>
              POST to this endpoint from your chatbot. It returns your System Prompt and the full conversation history so your AI always has the right context.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">

            {/* Endpoint */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Endpoint</p>
              <div className="relative group">
                <pre className="bg-background text-foreground p-3 rounded-lg border border-border font-mono text-sm overflow-x-auto">
                  <code>POST {webhookUrl}</code>
                </pre>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={copyWebhookUrl}
                >
                  {copiedWebhook ? <Check className="w-3 h-3 mr-1.5 text-emerald-500" /> : <Copy className="w-3 h-3 mr-1.5" />}
                  {copiedWebhook ? "Copied" : "Copy"}
                </Button>
              </div>
            </div>

            {/* How it works */}
            <div className="space-y-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">How it works — two-phase flow</p>
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="bg-background border border-border rounded-lg p-4 space-y-1.5">
                  <p className="text-xs font-semibold text-primary">① Fetch context (before AI call)</p>
                  <p className="text-xs text-muted-foreground">POST the customer's message with a <code className="bg-muted px-1 rounded">sessionId</code> but <em>no</em> <code className="bg-muted px-1 rounded">botResponse</code>. The response returns your <code className="bg-muted px-1 rounded">systemPrompt</code> and prior <code className="bg-muted px-1 rounded">conversationHistory</code>. Use these to call your AI.</p>
                </div>
                <div className="bg-background border border-border rounded-lg p-4 space-y-1.5">
                  <p className="text-xs font-semibold text-emerald-500">② Log the reply (after AI call)</p>
                  <p className="text-xs text-muted-foreground">POST again with the same <code className="bg-muted px-1 rounded">sessionId</code> and include <code className="bg-muted px-1 rounded">botResponse</code>. This stores the full turn so the next message will include it in history.</p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground">For simple bots, skip the two-phase flow — POST both <code className="bg-muted px-1 rounded">customerMessage</code> and <code className="bg-muted px-1 rounded">botResponse</code> together to log the turn directly.</p>
            </div>

            {/* Channel keys */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Which API key to use</p>
              <div className="grid gap-2 sm:grid-cols-3">
                {[
                  { channel: "telegram", label: "Telegram", key: "Telegram Bot Token" },
                  { channel: "whatsapp", label: "WhatsApp", key: "WhatsApp API Key" },
                  { channel: "website",  label: "Website",  key: "Website Widget Key" },
                ].map(({ channel, label, key }) => (
                  <div key={channel} className="bg-background border border-border rounded-lg p-3">
                    <p className="text-xs font-semibold text-primary mb-1">{label}</p>
                    <p className="text-xs text-muted-foreground">Use your <span className="text-foreground font-medium">{key}</span> as the <code className="text-xs bg-muted px-1 rounded">apiKey</code></p>
                  </div>
                ))}
              </div>
            </div>

            {/* Phase 1 example */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">① Request — fetch context</p>
              <pre className="bg-background text-foreground p-4 rounded-lg border border-border font-mono text-xs overflow-x-auto">
                <code>{webhookPhase1Example("website", company.websiteChatbotKey || "")}</code>
              </pre>
            </div>

            {/* Response example */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">← Response (use to build AI prompt)</p>
              <pre className="bg-background text-foreground p-4 rounded-lg border border-border font-mono text-xs overflow-x-auto">
                <code>{webhookResponseExample}</code>
              </pre>
            </div>

            {/* Phase 2 example */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">② Request — log the reply</p>
              <pre className="bg-background text-foreground p-4 rounded-lg border border-border font-mono text-xs overflow-x-auto">
                <code>{webhookPhase2Example("website", company.websiteChatbotKey || "")}</code>
              </pre>
            </div>

            <p className="text-xs text-muted-foreground border-t border-border pt-4">
              <code className="bg-muted px-1 rounded">sessionId</code> can be any stable string — Telegram <code className="bg-muted px-1 rounded">chat_id</code>, WhatsApp phone number, browser fingerprint, etc. History is scoped per company and per session. Invalid <code className="bg-muted px-1 rounded">apiKey</code> → <code className="bg-muted px-1 rounded">401</code>.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
