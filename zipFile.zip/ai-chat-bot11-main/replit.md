# ai-chat-bot6

An AI-powered chatbot admin platform ("Mission Control") with a React frontend and Express API backend.

## Stack

- **Frontend** (`artifacts/chatbot-admin`): React + Vite + Tailwind CSS, served at `/`
- **API Server** (`artifacts/api-server`): Express + TypeScript, served at `/api`
- **Database**: Replit PostgreSQL via Drizzle ORM (`lib/db`)
- **AI**: OpenAI integration (`lib/integrations-openai-ai-server`, `lib/integrations-openai-ai-react`)
- **Monorepo**: pnpm workspace

## Running the project

All three workflows start automatically:
- `artifacts/chatbot-admin: web` — frontend dev server
- `artifacts/api-server: API Server` — builds then starts the API
- `artifacts/mockup-sandbox: Component Preview Server` — canvas/design tool

## Environment variables / secrets

| Key | Required | Notes |
|---|---|---|
| `SESSION_SECRET` | ✅ | Session encryption key (already set) |
| `DATABASE_URL` | ✅ | Auto-managed by Replit |
| `OPENAI_API_KEY` | ⚠️ | Required for OpenAI chat features |
| `OPENROUTER_API_KEY` | ✅ | OpenRouter chat (free + full models) |

## Admin login

Default admin credentials (created during setup):
- **Username**: `admin`
- **Password**: `admin123`

> Change this password after first login.

## User preferences
